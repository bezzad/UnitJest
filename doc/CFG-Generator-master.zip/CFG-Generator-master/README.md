Introduction
-----------

Control flow graph generator is a project that aim to  enhance Compiler explorer UI in a sence that make assembly
code exploration easier by dividing the code into connected basic blocks and displaying them as a graph structure.







